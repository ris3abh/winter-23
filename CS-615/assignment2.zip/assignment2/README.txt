Libraries used:
numpy

All the coding and solution to the respective part of the assignments are in the "code" file.
1. layers.py:  contains the code for all the activation layers, input layers, fully connected layers classes and objective function classes.
2. part3.py: contains the solution for the 3rd part of the assignment where I have tested the gradient methods.
3. part4.py: contains the solution for the 4th part of the assignment where I have tested the objective layers.
4. Theory1.py: contains the solution to the theory questions in part1. This was only done for referencing the hand solved solutions with the coded solution and see if
i get the same output for all the layer.
