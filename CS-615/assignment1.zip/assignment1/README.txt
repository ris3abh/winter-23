code file contains all the code work for the assignment.
1. layers.py contains the implementation of all the layer classes.
2. testScript.py file contains the implementation of all the layers individually and in a form of network. 
    to test the script run python3 testScript.py
3. MedicalDF.ipynb. contains the model implementation on the medical cost dataset.

Modules used.

1. numpy
2. pandas(to read the csv file of medical cost dataset).